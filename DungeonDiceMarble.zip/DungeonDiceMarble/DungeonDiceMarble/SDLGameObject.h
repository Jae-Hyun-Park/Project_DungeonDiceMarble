#pragma once
#include <string>
#include <list>
#include "include\SDL_image.h"
using namespace std;

class Component;
class Transform;
// class Collider;

class SDLGameObject
{
private:
	list<Component*> components;

public:
	string name;
	Transform* transform = NULL;

	bool willBeDestroy = false;
	bool active = true;

	SDLGameObject(string _name);
	~SDLGameObject();

	template<class T>
	T* AddComponent()
	{
		T* pT = GetComponent<T>();

		// �ش� ������Ʈ Ÿ���� �������� �ʴ� ��쿡�� ���� �߰� ����
		if (pT == NULL)
		{
			pT = new T();
			components.push_back(pT);
			components.back()->gameObject = this;
			components.back()->Init();
		}

		return pT;
	}

	template<typename T>
	T* GetComponent()
	{
		T* pT = NULL;
		for (auto component : components)
		{
			pT = dynamic_cast<T*>(component);
			if (pT == NULL)
				continue;
			else
				break;
		}

		return pT;
	}


	// EventHandle
	void HandleEvent(SDL_Event* e);

	// Update
	void Update(float deltaTime);

	// Render
	void Render();

	//void OnCollisionEnter(Collider* other);
	//void OnCollisionStay(Collider* other);
	//void OnCollisionExit(Collider* other);
};

